package repository;

import model.Loan;
import exception.InvalidLoanException;
import java.util.List;

public interface ILoanRepository {

    // a. Apply for loan, initially loan status is pending
    void applyLoan(Loan loan);

    // b. Calculate interest for a loan by loanId
    double calculateInterest(int loanId) throws InvalidLoanException;

    // b.i. Overloaded method to calculate loan interest using parameters
    double calculateInterest(double principalAmount, double interestRate, int loanTerm);

    // c. Determine loan status (Approved/Rejected based on credit score)
    void loanStatus(int loanId) throws InvalidLoanException;

    // d. Calculate EMI for a loan by loanId
    double calculateEMI(int loanId) throws InvalidLoanException;

    // d.i. Overloaded method to calculate EMI using parameters
    double calculateEMI(double loanAmount, double interestRate, int loanTerm);

    // e. Loan repayment: Calculate the number of EMIs that can be paid with the given amount
    void loanRepayment(int loanId, double amount) throws InvalidLoanException;

    // f. Get all loans and return as a list
    List<Loan> getAllLoan();

    // g. Get loan by ID and print the details
    Loan getLoanById(int loanId) throws InvalidLoanException;
}