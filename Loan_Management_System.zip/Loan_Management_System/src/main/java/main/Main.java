package main;
import java.util.Scanner;

import exception.InvalidLoanException;
import model.CarLoan;
import model.HomeLoan;
import model.Loan;

import java.util.List;
import repository.ILoanRepository;
import repository.LoanRepositoryImpl;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ILoanRepository loanRepo = new LoanRepositoryImpl();
        
        while (true) {
            // Display the menu
            System.out.println("\n===== Loan Management System =====");
            System.out.println("1. Apply for a loan");
            System.out.println("2. Calculate loan interest");
            System.out.println("3. Check loan status");
            System.out.println("4. Calculate EMI");
            System.out.println("5. Repay loan");
            System.out.println("6. View all loans");
            System.out.println("7. View loan details by ID");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            
            switch (choice) {
            case 1:
                // Apply for a loan
                System.out.println("Enter loan details:");
                System.out.print("Customer ID: ");
                int customerId = scanner.nextInt();
                System.out.print("Loan Amount: ");
                double loanAmount = scanner.nextDouble();
                System.out.print("Interest Rate: ");
                double interestRate = scanner.nextDouble();
                System.out.print("Loan Term (in months): ");
                int loanTerm = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                System.out.print("Loan Type (HomeLoan/CarLoan): ");
                String loanType = scanner.nextLine();
                
                if (loanType.equalsIgnoreCase("HomeLoan")) {
                    // If the loan is a HomeLoan
                    System.out.print("Property Address: ");
                    String propertyAddress = scanner.nextLine();
                    System.out.print("Property Value: ");
                    int propertyValue = scanner.nextInt();

                    HomeLoan homeLoan = new HomeLoan();
                    homeLoan.setCustomerId(customerId);
                    homeLoan.setLoanAmount(loanAmount);
                    homeLoan.setInterestRate(interestRate);
                    homeLoan.setLoanTerm(loanTerm);
                    homeLoan.setLoanType(loanType);
                    homeLoan.setPropertyAddress(propertyAddress);
                    homeLoan.setPropertyValue(propertyValue);
                    homeLoan.setLoanStatus("Pending");

                    loanRepo.applyLoan(homeLoan);
                    
                } else if (loanType.equalsIgnoreCase("CarLoan")) {
                    // If the loan is a CarLoan
                    System.out.print("Car Model: ");
                    String carModel = scanner.nextLine();
                    System.out.print("Car Value: ");
                    int carValue = scanner.nextInt();

                    CarLoan carLoan = new CarLoan();
                    carLoan.setCustomerId(customerId);
                    carLoan.setLoanAmount(loanAmount);
                    carLoan.setInterestRate(interestRate);
                    carLoan.setLoanTerm(loanTerm);
                    carLoan.setLoanType(loanType);
                    carLoan.setCarModel(carModel);
                    carLoan.setCarValue(carValue);
                    carLoan.setLoanStatus("Pending");

                    loanRepo.applyLoan(carLoan);
                    
                } else {
                    // Handle invalid loan type
                    System.out.println("Invalid loan type. Please choose either 'HomeLoan' or 'CarLoan'.");
                }
                break;

                
                case 2:
                    // Calculate loan interest
                    System.out.print("Enter loan ID: ");
                    int loanInterest = scanner.nextInt();
                    try {
                        double interest = loanRepo.calculateInterest(loanInterest);
                        System.out.println("Loan Interest: " + interest);
                    } catch (InvalidLoanException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                
                case 3:
                    // Check loan status
                    System.out.print("Enter loan ID: ");
                    int loanStatus = scanner.nextInt();
                    try {
                        loanRepo.loanStatus(loanStatus);
                    } catch (InvalidLoanException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                
                case 4:
                    // Calculate EMI
                    System.out.print("Enter loan ID: ");
                    int loanIdForEmi = scanner.nextInt();
                    try {
                        double emi = loanRepo.calculateEMI(loanIdForEmi);
                        System.out.println("Monthly EMI: " + emi);
                    } catch (InvalidLoanException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                
                case 5:
                    // Repay loan
                    System.out.print("Enter loan ID: ");
                    int loanIdForRepayment = scanner.nextInt();
                    System.out.print("Enter repayment amount: ");
                    double repaymentAmount = scanner.nextDouble();
                    try {
                        loanRepo.loanRepayment(loanIdForRepayment, repaymentAmount);
                    } catch (InvalidLoanException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                
                case 6:
                    // View all loans
                    List<Loan> loans = loanRepo.getAllLoan();
                    if (loans.isEmpty()) {
                        System.out.println("No loans found.");
                    } else {
                        for (Loan loanDetails : loans) {
                            System.out.println(loanDetails);
                        }
                    }
                    break;
                
                case 7:
                    // View loan details by ID
                    System.out.print("Enter loan ID: ");
                    int loanIdForDetails = scanner.nextInt();
                    try {
                        Loan loanDetails = loanRepo.getLoanById(loanIdForDetails);
                        System.out.println(loanDetails);
                    } catch (InvalidLoanException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                
                case 8:
                    // Exit
                    System.out.println("Exiting Loan Management System...");
                    scanner.close();
                    System.exit(0);
                    break;
                
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}