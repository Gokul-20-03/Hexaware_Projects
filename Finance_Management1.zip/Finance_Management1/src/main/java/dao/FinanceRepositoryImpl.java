package dao;

import entity.Category;
import entity.Expense;
import entity.User;
import exceptions.ExpenseNotFoundException;
import exceptions.UserNotFoundException;
import util.DBConnUtil;
import util.DBPropertyUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FinanceRepositoryImpl implements IFinanceRepository {

    private Connection conn;

    public FinanceRepositoryImpl() {
        // Get the properties from the db.properties file
        String url = DBPropertyUtil.getPropertyString("db.url");
        String username = DBPropertyUtil.getPropertyString("db.username");
        String password = DBPropertyUtil.getPropertyString("db.password");

        // Check if properties are loaded correctly
        if (url != null && username != null && password != null) {
            conn = DBConnUtil.getConnection(url, username, password);  // Pass the URL, username, and password to DBConnUtil
        } else {
            System.out.println("Database properties are missing. Cannot connect to the database.");
        }
    }

    @Override
    public boolean createUser(User user) {
        String query = "INSERT INTO Users(username, password, email) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getEmail());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean createCategory(Category category) {
        String query = "INSERT INTO Categories(category_name) VALUES (?)";
        try (PreparedStatement ps = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, category.getCategoryName());
            int affectedRows = ps.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        category.setCategoryId(generatedKeys.getInt(1));  // Set auto-generated category ID
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean deleteUser(int userId) {
        String query = "DELETE FROM Users WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId);
            int result = ps.executeUpdate();
            if (result == 0) {
                throw new UserNotFoundException("User ID not found: " + userId);
            }
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (UserNotFoundException e) {
            System.out.println(e.getMessage());  // Log specific error message
        }
        return false;
    }

    @Override
    public boolean createExpense(Expense expense) {
        String query = "INSERT INTO Expenses(user_id, amount, category_id, date, description) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, expense.getUserId());
            ps.setDouble(2, expense.getAmount());
            ps.setInt(3, expense.getCategoryId());
            ps.setDate(4, expense.getDate());
            ps.setString(5, expense.getDescription());
            int affectedRows = ps.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        expense.setExpenseId(generatedKeys.getInt(1));  // Set auto-generated expense ID
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean deleteExpense(int expenseId) {
        String query = "DELETE FROM Expenses WHERE expense_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, expenseId);
            int result = ps.executeUpdate();
            if (result == 0) {
                throw new ExpenseNotFoundException("Expense ID not found: " + expenseId);
            }
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ExpenseNotFoundException e) {
            System.out.println(e.getMessage());  // Log specific error message
        }
        return false;
    }

    @Override
    public boolean updateExpense(int userId, Expense expense) {
        String query = "UPDATE Expenses SET amount=?, category_id=?, date=?, description=? WHERE expense_id=? AND user_id=?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setDouble(1, expense.getAmount());
            ps.setInt(2, expense.getCategoryId());
            ps.setDate(3, expense.getDate());
            ps.setString(4, expense.getDescription());
            ps.setInt(5, expense.getExpenseId());
            ps.setInt(6, userId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<Expense> getAllExpenses(int userId) {
        List<Expense> list = new ArrayList<>();
        String query = "SELECT * FROM Expenses WHERE user_id=?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Expense e = new Expense(
                        rs.getInt("expense_id"),
                        rs.getInt("user_id"),
                        rs.getDouble("amount"),
                        rs.getInt("category_id"),
                        rs.getDate("date"),
                        rs.getString("description")
                );
                list.add(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Category> getAllCategories() {
        List<Category> categories = new ArrayList<>();
        String query = "SELECT * FROM Categories";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Category category = new Category(
                        rs.getInt("category_id"),
                        rs.getString("category_name")
                );
                categories.add(category);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return categories;
    }
}
