package dao;

import entity.Category;
import entity.Expense;
import entity.User;

import java.util.List;

public interface IFinanceRepository {

    boolean createUser(User user);
    boolean createCategory(Category category);
    boolean deleteUser(int userId);
    boolean createExpense(Expense expense);
    boolean deleteExpense(int expenseId);
    boolean updateExpense(int userId, Expense expense);
    List<Expense> getAllExpenses(int userId);
    List<Category> getAllCategories();
}
