package util;

import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {
    public static String getPropertyString(String key) {
        String value = null;
        try (InputStream input = DBPropertyUtil.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (input == null) {
                System.out.println("Sorry, unable to find db.properties");
                return null;
            }
            Properties prop = new Properties();
            prop.load(input);
            value = prop.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return value;
    }
}
