package app;

import dao.FinanceRepositoryImpl;
import dao.IFinanceRepository;
import entity.Expense;
import entity.User;
import entity.Category;
import exceptions.ExpenseNotFoundException;
import exceptions.UserNotFoundException;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        IFinanceRepository repo = new FinanceRepositoryImpl();

        while (true) {
            System.out.println("\n==== Finance Management System ====");
            System.out.println("1. Add User");
            System.out.println("2. Add Expense Category");
            System.out.println("3. Add Expense");
            System.out.println("4. Delete User");
            System.out.println("5. Delete Expense");
            System.out.println("6. Update Expense");
            System.out.println("7. View All Expenses for a User");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine();  // consume newline

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter Username: ");
                        String uname = sc.nextLine();
                        System.out.print("Enter Password: ");
                        String pwd = sc.nextLine();
                        System.out.print("Enter Email: ");
                        String email = sc.nextLine();

                        User user = new User(0,uname, pwd, email);
                        if (repo.createUser(user)) {
                            System.out.println("User added successfully.");
                        } else {
                            System.out.println("Failed to add user.");
                        }
                        break;

                    case 2:
                        System.out.print("Enter Category Name: ");
                        String categoryName = sc.nextLine();

                        Category category = new Category(0, categoryName); // ID auto-generated
                        if (repo.createCategory(category)) {
                            System.out.println("Category added successfully.");
                        } else {
                            System.out.println("Failed to add category.");
                        }
                        break;

                    case 3:
                        System.out.print("Enter Expense ID: ");
                        int eid = sc.nextInt();
                        System.out.print("Enter User ID: ");
                        int userId = sc.nextInt();
                        System.out.print("Enter Amount: ");
                        int amount = sc.nextInt();
                        System.out.print("Enter Category ID: ");
                        int cid = sc.nextInt();
                        sc.nextLine(); // consume newline
                        System.out.print("Enter Date (yyyy-mm-dd): ");
                        String dateStr = sc.nextLine();
                        Date date = Date.valueOf(dateStr);
                        System.out.print("Enter Description: ");
                        String desc = sc.nextLine();

                        Expense expense = new Expense(eid, userId, amount, cid, date, desc);
                        if (repo.createExpense(expense)) {
                            System.out.println("Expense added successfully.");
                        } else {
                            System.out.println("Failed to add expense.");
                        }
                        break;

                    case 4:
                        System.out.print("Enter User ID to delete: ");
                        int delUserId = sc.nextInt();
                        if (repo.deleteUser(delUserId)) {
                            System.out.println("User deleted successfully.");
                        } else {
                            throw new UserNotFoundException("User ID not found: " + delUserId);
                        }
                        break;

                    case 5:
                        System.out.print("Enter Expense ID to delete: ");
                        int delExpenseId = sc.nextInt();
                        if (repo.deleteExpense(delExpenseId)) {
                            System.out.println("Expense deleted successfully.");
                        } else {
                            throw new ExpenseNotFoundException("Expense ID not found: " + delExpenseId);
                        }
                        break;

                    case 6:
                        System.out.print("Enter User ID: ");
                        int upUserId = sc.nextInt();
                        System.out.print("Enter Expense ID: ");
                        int upExpId = sc.nextInt();
                        System.out.print("Enter Updated Amount: ");
                        int upAmount = sc.nextInt();
                        System.out.print("Enter Updated Category ID: ");
                        int upCatId = sc.nextInt();
                        sc.nextLine(); // consume newline
                        System.out.print("Enter Updated Date (yyyy-mm-dd): ");
                        String upDateStr = sc.nextLine();
                        Date upDate = Date.valueOf(upDateStr);
                        System.out.print("Enter Updated Description: ");
                        String upDesc = sc.nextLine();

                        Expense updatedExpense = new Expense(upExpId, upUserId, upAmount, upCatId, upDate, upDesc);
                        if (repo.updateExpense(upUserId, updatedExpense)) {
                            System.out.println("Expense updated successfully.");
                        } else {
                            throw new ExpenseNotFoundException("Expense not found for update.");
                        }
                        break;

                    case 7:
                        System.out.print("Enter User ID to view expenses: ");
                        int expUserId = sc.nextInt();
                        List<Expense> expenses = repo.getAllExpenses(expUserId);
                        if (expenses.isEmpty()) {
                            System.out.println("No expenses found.");
                        } else {
                            for (Expense exp : expenses) {
                                System.out.println(exp);
                            }
                        }
                        break;

                    case 8:
                        System.out.println("Exiting... Goodbye!");
                        sc.close();
                        System.exit(0);
                        break;

                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            } catch (UserNotFoundException | ExpenseNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected error occurred: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}
