package util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {

    private static final String PROPERTIES_FILE = "/db.properties";
    private static Properties properties = null;

    // Private constructor to prevent instantiation
    private DBPropertyUtil() {
    }

    // Method to load properties from the file
    private static void loadProperties() throws IOException {
        if (properties == null) {
            properties = new Properties();
            try (InputStream inputStream = DBPropertyUtil.class.getResourceAsStream(PROPERTIES_FILE)) {
                if (inputStream == null) {
                    throw new IOException("Property file '" + PROPERTIES_FILE + "' not found in classpath");
                }
                properties.load(inputStream);
            }
        }
    }

    // Method to get the database URL
    public static String getDBUrl() throws IOException {
        loadProperties();
        return properties.getProperty("db.url");
    }

    // Method to get the database user
    public static String getDBUser() throws IOException {
        loadProperties();
        return properties.getProperty("db.user");
    }

    // Method to get the database password
    public static String getDBPassword() throws IOException {
        loadProperties();
        return properties.getProperty("db.password");
    }

    // Method to get any property by key
    public static String getProperty(String key) throws IOException {
        loadProperties();
        return properties.getProperty(key);
    }
}
