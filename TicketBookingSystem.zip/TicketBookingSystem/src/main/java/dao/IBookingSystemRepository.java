package dao;

import bean.Booking;
import bean.Event;
import java.util.List;

public interface IBookingSystemRepository {
    void createEvent(Event event);
    Event getEventById(int eventId);
    List<Event> getAllEvents();
    void updateEvent(Event event);
    boolean bookTicket(int eventId, int customerId, int numOfTickets);
    void cancelBooking(int bookingId);
    Booking getBookingById(int bookingId);
	void cancelBooking(int eventId, int numTickets);
}
