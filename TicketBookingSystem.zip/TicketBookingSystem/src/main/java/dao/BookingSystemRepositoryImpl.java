package dao;

import bean.Booking;
import bean.Event;
import util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookingSystemRepositoryImpl implements IBookingSystemRepository {

    @Override
    public void createEvent(Event event) {
        String query = "INSERT INTO events (event_id, event_name, event_date, event_time, venue_id, total_seats, ticket_price, event_type) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DBUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, event.getEventId());
            ps.setString(2, event.getEventName());
            ps.setDate(3, Date.valueOf(event.getEventDate()));
            ps.setTime(4, Time.valueOf(event.getEventTime()));
            ps.setInt(5, event.getVenue().getVenueId());
            ps.setInt(6, event.getTotalSeats());
            ps.setDouble(7, event.getTicketPrice());
            ps.setString(8, event.getEventType());

            ps.executeUpdate();
            System.out.println("Event created successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Event getEventById(int eventId) {
        String query = "SELECT * FROM events WHERE event_id = ?";
        Event event = null;

        
        return event;
    }

    @Override
    public List<Event> getAllEvents() {
        String query = "SELECT * FROM events";
        List<Event> events = new ArrayList<>();

        
        return events;
    }

    @Override
    public void updateEvent(Event event) {
        String query = "UPDATE events SET event_name = ?, event_date = ?, event_time = ?, venue_id = ?, total_seats = ?, ticket_price = ?, event_type = ? WHERE event_id = ?";

        try (Connection connection = DBUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setString(1, event.getEventName());
            ps.setDate(2, Date.valueOf(event.getEventDate()));
            ps.setTime(3, Time.valueOf(event.getEventTime()));
            ps.setInt(4, event.getVenue().getVenueId());
            ps.setInt(5, event.getTotalSeats());
            ps.setDouble(6, event.getTicketPrice());
            ps.setString(7, event.getEventType());
            ps.setInt(8, event.getEventId());

            ps.executeUpdate();
            System.out.println("Event updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean bookTicket(int eventId, int customerId, int numOfTickets) {
        String query = "SELECT available_seats FROM events WHERE event_id = ?";
        boolean success = false;

        try (Connection connection = DBUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, eventId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int availableSeats = rs.getInt("available_seats");
                if (availableSeats >= numOfTickets) {
                    String updateQuery = "UPDATE events SET available_seats = available_seats - ? WHERE event_id = ?";
                    try (PreparedStatement updatePs = connection.prepareStatement(updateQuery)) {
                        updatePs.setInt(1, numOfTickets);
                        updatePs.setInt(2, eventId);
                        updatePs.executeUpdate();

                        // Assume that Booking object creation and insertion is handled elsewhere.
                        success = true;
                        System.out.println("Tickets booked successfully!");
                    }
                } else {
                    System.out.println("Not enough tickets available.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return success;
    }

    @Override
    public void cancelBooking(int bookingId) {
        // Fetch booking by ID (assuming there’s a bookings table)
        String query = "SELECT event_id, num_of_tickets FROM bookings WHERE booking_id = ?";
        try (Connection connection = DBUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, bookingId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int eventId = rs.getInt("event_id");
                int numOfTickets = rs.getInt("num_of_tickets");

                // Update event's available seats
                String updateQuery = "UPDATE events SET available_seats = available_seats + ? WHERE event_id = ?";
                try (PreparedStatement updatePs = connection.prepareStatement(updateQuery)) {
                    updatePs.setInt(1, numOfTickets);
                    updatePs.setInt(2, eventId);
                    updatePs.executeUpdate();

                    // Assuming cancellation of booking in the bookings table is handled elsewhere
                    System.out.println("Booking cancelled successfully!");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Booking getBookingById(int bookingId) {
        // Assuming a booking table and retrieving the booking by ID
        String query = "SELECT * FROM bookings WHERE booking_id = ?";
        Booking booking = null;

        try (Connection connection = DBUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, bookingId);
            ResultSet rs = ps.executeQuery();

          
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return booking;
    }

    @Override
    public void cancelBooking(int eventId, int numTickets) {
        // Similar to the cancelBooking with bookingId method, cancel tickets for an event
        String query = "UPDATE events SET available_seats = available_seats + ? WHERE event_id = ?";

        try (Connection connection = DBUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, numTickets);
            ps.setInt(2, eventId);
            ps.executeUpdate();
            System.out.println("Tickets cancelled successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
}
