package app;

import bean.*;
import service.BookingSystemServiceProviderImpl;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TicketBookingSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BookingSystemServiceProviderImpl system = new BookingSystemServiceProviderImpl();

        while (true) {
            System.out.println("\n====== Ticket Booking System ======");
            System.out.println("1. Create Event");
            System.out.println("2. View All Events");
            System.out.println("3. Book Tickets");
            System.out.println("4. Cancel Booking");
            System.out.println("5. View Booking Details");
            System.out.println("6. Check Available Tickets");
            System.out.println("0. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    // Create Event
                    System.out.print("Enter Event ID: ");
                    int eventId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Event Name: ");
                    String eventName = sc.nextLine();
                    System.out.print("Enter Event Date (YYYY-MM-DD): ");
                    LocalDate date = LocalDate.parse(sc.nextLine());
                    System.out.print("Enter Event Time (HH:MM): ");
                    LocalTime time = LocalTime.parse(sc.nextLine());
                    System.out.print("Enter Total Seats: ");
                    int totalSeats = sc.nextInt();
                    System.out.print("Enter Ticket Price: ");
                    double price = sc.nextDouble();
                    sc.nextLine();
                    System.out.print("Enter Event Type (Movie/Concert/Sports): ");
                    String type = sc.nextLine();

                    // Venue Details
                    System.out.print("Enter Venue ID: ");
                    int venueId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Venue Name: ");
                    String venueName = sc.nextLine();
                    System.out.print("Enter Venue Address: ");
                    String address = sc.nextLine();
                    Venue venue = new Venue(venueId, venueName, address);

                    system.createEvent(eventId, eventName, date, time, totalSeats, price, type, venue);
                    break;

                case 2:
                    // View all events
                    List<Event> events = system.getEventDetails();
                    if (events.isEmpty()) {
                        System.out.println("No events available.");
                    } else {
                        for (Event event : events) {
                            System.out.println();
                            event.displayEventDetails();
                        }
                    }
                    break;

                case 3:
                    // Book tickets
                    System.out.print("Enter Event Name: ");
                    String bookingEventName = sc.nextLine();
                    System.out.print("Enter number of tickets to book: ");
                    int ticketCount = sc.nextInt();
                    sc.nextLine();

                    List<Customer> customerList = new ArrayList<>();
                    for (int i = 0; i < ticketCount; i++) {
                        System.out.println("Enter details for Customer " + (i + 1));
                        System.out.print("Enter Customer ID: ");
                        int customerId = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter Name: ");
                        String name = sc.nextLine();
                        System.out.print("Enter Email: ");
                        String email = sc.nextLine();
                        System.out.print("Enter Phone Number: ");
                        String phone = sc.nextLine();

                        Customer customer = new Customer(customerId, name, email, phone);
                        customerList.add(customer);
                    }

                    system.bookTickets(bookingEventName, ticketCount, customerList);
                    break;

                case 4:
                    // Cancel booking
                    System.out.print("Enter Booking ID to cancel: ");
                    int cancelId = sc.nextInt();
                    system.cancelBooking(cancelId);
                    break;

                case 5:
                    // View booking
                    System.out.print("Enter Booking ID to view: ");
                    int viewId = sc.nextInt();
                    system.getBookingDetails(viewId);
                    break;

                case 6:
                    // Check available tickets
                    System.out.print("Enter Event Name: ");
                    String checkName = sc.nextLine();
                    int available = system.getAvailableNoOfTickets(checkName);
                    System.out.println("Available Tickets for " + checkName + ": " + available);
                    break;

                case 0:
                    System.out.println("Exiting... Thank you!");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
