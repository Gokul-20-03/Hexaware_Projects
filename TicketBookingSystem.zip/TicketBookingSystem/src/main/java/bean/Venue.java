package bean;

public class Venue {
    private int venueId;
    private String venueName;
    private String address;

    // Default constructor
    public Venue() {
    }

    // Overloaded constructor
    public Venue(int venueId, String venueName, String address) {
        this.venueId = venueId;
        this.venueName = venueName;
        this.address = address;
    }

    // Getters and Setters
    public int getVenueId() {
        return venueId;
    }

    public void setVenueId(int venueId) {
        this.venueId = venueId;
    }

    public String getVenueName() {
        return venueName;
    }

    public void setVenueName(String venueName) {
        this.venueName = venueName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    // Display method
    public void displayVenueDetails() {
        System.out.println("Venue ID   : " + venueId);
        System.out.println("Venue Name : " + venueName);
        System.out.println("Address    : " + address);
    }
}
