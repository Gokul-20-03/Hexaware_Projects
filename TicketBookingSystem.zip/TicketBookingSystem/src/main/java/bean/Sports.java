package bean;

import java.time.LocalDate;
import java.time.LocalTime;

public class Sports extends Event {
    private String sportName;
    private String teamsName;

    public Sports() {
        super();
    }

    public Sports(int eventId, String eventName, LocalDate eventDate, LocalTime eventTime, Venue venue,
                  int totalSeats, double ticketPrice, String sportName, String teamsName) {
        super(eventId, eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, "Sports");
        this.sportName = sportName;
        this.teamsName = teamsName;
    }

    public String getSportName() {
        return sportName;
    }

    public void setSportName(String sportName) {
        this.sportName = sportName;
    }

    public String getTeamsName() {
        return teamsName;
    }

    public void setTeamsName(String teamsName) {
        this.teamsName = teamsName;
    }

    @Override
    public void displayEventDetails() {
        System.out.println("=== Sports Event ===");
        System.out.println("Event ID   : " + getEventId());
        System.out.println("Name       : " + getEventName());
        System.out.println("Date       : " + getEventDate());
        System.out.println("Time       : " + getEventTime());
        System.out.println("Sport      : " + sportName);
        System.out.println("Teams      : " + teamsName);
        System.out.println("Venue      : " + getVenue().getVenueName());
        System.out.println("Available  : " + getAvailableSeats() + "/" + getTotalSeats());
        System.out.println("Price      : ₹" + getTicketPrice());
    }
}
