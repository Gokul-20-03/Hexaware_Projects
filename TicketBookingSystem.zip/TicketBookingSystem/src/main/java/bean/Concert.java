package bean;

import java.time.LocalDate;
import java.time.LocalTime;

public class Concert extends Event {
    private String artist;
    private String type;

    public Concert() {
        super();
    }

    public Concert(int eventId, String eventName, LocalDate eventDate, LocalTime eventTime, Venue venue,
                   int totalSeats, double ticketPrice, String artist, String type) {
        super(eventId, eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, "Concert");
        this.artist = artist;
        this.type = type;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public void displayEventDetails() {
        System.out.println("=== Concert Event ===");
        System.out.println("Event ID   : " + getEventId());
        System.out.println("Name       : " + getEventName());
        System.out.println("Date       : " + getEventDate());
        System.out.println("Time       : " + getEventTime());
        System.out.println("Artist     : " + artist);
        System.out.println("Type       : " + type);
        System.out.println("Venue      : " + getVenue().getVenueName());
        System.out.println("Available  : " + getAvailableSeats() + "/" + getTotalSeats());
        System.out.println("Price      : ₹" + getTicketPrice());
    }
}
