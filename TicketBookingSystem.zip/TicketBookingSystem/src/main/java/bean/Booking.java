package bean;

import java.time.LocalDateTime;
import java.util.List;

public class Booking {
    private static int bookingCounter = 1000; // Static counter to auto-generate booking IDs

    private int bookingId;
    private List<Customer> customers;
    private Event event;
    private int numTickets;
    private double totalCost;
    private LocalDateTime bookingDate;

    // Default constructor
    public Booking() {
    }

    // Overloaded constructor
    public Booking(List<Customer> customers, Event event, int numTickets) {
        this.bookingId = bookingCounter++;
        this.customers = customers;
        this.event = event;
        this.numTickets = numTickets;
        this.totalCost = calculateBookingCost(numTickets);
        this.bookingDate = LocalDateTime.now();
    }

    // Getters and Setters
    public int getBookingId() {
        return bookingId;
    }

    public List<Customer> getCustomers() {
        return customers;
    }

    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    public int getNumTickets() {
        return numTickets;
    }

    public void setNumTickets(int numTickets) {
        this.numTickets = numTickets;
        this.totalCost = calculateBookingCost(numTickets); // Recalculate if ticket count changes
    }

    public double getTotalCost() {
        return totalCost;
    }

    public LocalDateTime getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDateTime bookingDate) {
        this.bookingDate = bookingDate;
    }

    // Calculates cost based on number of tickets
    public double calculateBookingCost(int numTickets) {
        return event.getTicketPrice() * numTickets;
    }

    // Display method
    public void displayBookingDetails() {
        System.out.println("=== Booking Details ===");
        System.out.println("Booking ID   : " + bookingId);
        System.out.println("Event Name   : " + event.getEventName());
        System.out.println("Event Type   : " + event.getEventType());
        System.out.println("Venue        : " + event.getVenue().getVenueName());
        System.out.println("Tickets Booked: " + numTickets);
        System.out.println("Total Cost   : ₹" + totalCost);
        System.out.println("Booking Date : " + bookingDate);
        System.out.println("--- Customers ---");
        for (Customer customer : customers) {
            customer.displayCustomerDetails();
            System.out.println();
        }
    }
}
