package exception;

public class TicketBookingException extends Exception {
    public TicketBookingException(String message) {
        super(message);
    }
}
