package service;

import bean.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class EventServiceProviderImpl implements IEventServiceProvider {

    // List to store all events
    protected List<Event> events = new ArrayList<>();

    @Override
    public Event createEvent(int eventId, String eventName, LocalDate eventDate, LocalTime eventTime,
                             int totalSeats, double ticketPrice, String eventType, Venue venue) {

        Event event = null;

        switch (eventType.toLowerCase()) {
            case "movie":
                // Example dummy data for extra fields
                event = new Movie(eventId, eventName, eventDate, eventTime, venue,
                        totalSeats, ticketPrice, "Action", "John Doe", "Jane Doe");
                break;

            case "concert":
                event = new Concert(eventId, eventName, eventDate, eventTime, venue,
                        totalSeats, ticketPrice, "Coldplay", "Rock");
                break;

            case "sports":
                event = new Sports(eventId, eventName, eventDate, eventTime, venue,
                        totalSeats, ticketPrice, "Cricket", "India vs Pakistan");
                break;

            default:
                System.out.println("Invalid event type provided.");
                return null;
        }

        events.add(event);
        System.out.println("Event created successfully: " + eventName);
        return event;
    }

    @Override
    public List<Event> getEventDetails() {
        return events;
    }

    @Override
    public int getAvailableNoOfTickets(String eventName) {
        for (Event event : events) {
            if (event.getEventName().equalsIgnoreCase(eventName)) {
                return event.getAvailableSeats();
            }
        }
        return 0;
    }
}
