package service;

import bean.Booking;
import bean.Customer;
import bean.Event;
import java.util.List;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BookingSystemServiceProviderImpl extends EventServiceProviderImpl implements IBookingSystemServiceProvider {

    // Store bookings with bookingId as key
    private Map<Integer, Booking> bookings = new HashMap<>();

    public BookingSystemServiceProviderImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
    public Booking bookTickets(String eventName, int numTickets, List<Customer> customers) {
        Event selectedEvent = null;

        // Find the event
        for (Event event : events) {  // Assuming `events` is inherited from EventServiceProviderImpl
            if (event.getEventName().equalsIgnoreCase(eventName)) {
                selectedEvent = event;
                break;
            }
        }

        if (selectedEvent == null) {
            System.out.println("Event not found!");
            return null;
        }

        // Check seat availability
        if (selectedEvent.getAvailableSeats() < numTickets) {
            System.out.println("Not enough tickets available for the event.");
            return null;
        }

        // Book the tickets
        boolean bookingSuccess = selectedEvent.bookTickets(numTickets);
        if (bookingSuccess) {
            Booking booking = new Booking(customers, selectedEvent, numTickets); // Assuming Booking has this constructor
            bookings.put(booking.getBookingId(), booking);
            System.out.println("Booking successful! Booking ID: " + booking.getBookingId());
            return booking;
        } else {
            System.out.println("Booking failed.");
            return null;
        }
    }

    @Override
    public boolean cancelBooking(int bookingId) {
        Booking booking = bookings.get(bookingId);
        if (booking == null) {
            System.out.println("Booking not found with ID: " + bookingId);
            return false;
        }

        // Cancel the booking and update the event
        booking.getEvent().cancelBooking(booking.getNumTickets());
        bookings.remove(bookingId);
        System.out.println("Booking cancelled successfully for ID: " + bookingId);
        return true;
    }

    @Override
    public Booking getBookingDetails(int bookingId) {
        Booking booking = bookings.get(bookingId);
        if (booking != null) {
            booking.displayBookingDetails();  // Assuming this method exists in Booking
            return booking;
        } else {
            System.out.println("No booking found with ID: " + bookingId);
            return null;
        }
    }

	public int getAvailableNoOfTickets(String checkName) {
		// TODO Auto-generated method stub
		return 0;
	}
}
