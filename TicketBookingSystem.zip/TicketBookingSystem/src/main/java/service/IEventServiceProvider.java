package service;

import bean.Event;
import bean.Venue;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface IEventServiceProvider {

    Event createEvent(int eventId, String eventName, LocalDate eventDate, LocalTime eventTime,
                      int totalSeats, double ticketPrice, String eventType, Venue venue);

    List<Event> getEventDetails();

    int getAvailableNoOfTickets(String eventName);
}
