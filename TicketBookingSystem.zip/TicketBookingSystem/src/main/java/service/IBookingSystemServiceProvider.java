package service;

import bean.Booking;
import bean.Customer;

import java.util.List;

public interface IBookingSystemServiceProvider {

    Booking bookTickets(String eventName, int numTickets, List<Customer> customers);

    boolean cancelBooking(int bookingId);

    Booking getBookingDetails(int bookingId);
}
